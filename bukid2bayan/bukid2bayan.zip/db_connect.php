<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bukid2bayan"; // WALANG SPACE!

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- AUTO CREATE TRACKING SYSTEM TABLES ---
$conn->query("CREATE TABLE IF NOT EXISTS tracking_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  status VARCHAR(30) NOT NULL,
  location VARCHAR(255),
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX(order_id)
)");

$conn->query("ALTER TABLE orders ADD COLUMN IF NOT EXISTS tracking_number VARCHAR(50)");
$conn->query("ALTER TABLE orders ADD COLUMN IF NOT EXISTS courier VARCHAR(50) DEFAULT 'BUKID2BAYAN Xpress'");
$conn->query("ALTER TABLE orders ADD COLUMN IF NOT EXISTS farmer_lat DECIMAL(10,7) DEFAULT 14.3320");
$conn->query("ALTER TABLE orders ADD COLUMN IF NOT EXISTS farmer_lng DECIMAL(10,7) DEFAULT 121.0850");

function addTracking($conn, $order_id, $status, $location, $desc){
    $stmt = $conn->prepare("INSERT INTO tracking_logs (order_id, status, location, description) VALUES (?, ?, ?, ?)");
    if(!$stmt) return false;
    $stmt->bind_param("isss", $order_id, $status, $location, $desc);
    $stmt->execute();
    $stmt->close();
    return true;
}
?>